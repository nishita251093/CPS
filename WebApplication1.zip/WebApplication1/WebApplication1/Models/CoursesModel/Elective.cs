﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models.CoursesModel
{
    public class Elective
    {
        String electiveClass;
        String rubric;
        String underMajor;
        String UnderSpeciallization;

        public Elective(string electiveClass, string rubric, string underMajor, string underSpeciallization)
        {
            this.electiveClass = electiveClass;
            this.rubric = rubric;
            this.underMajor = underMajor;
            UnderSpeciallization = underSpeciallization;
        }
    }
}