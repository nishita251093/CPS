﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models.CoursesModel
{
    public class Core
    {
        String corCourseName;
        String rubric;
        String undeMajor;
        String available;
        String underSpecialization;

        public Core(string corCourseName, string rubric, string undeMajor, string available, string underSpecialization)
        {
            this.corCourseName = corCourseName;
            this.rubric = rubric;
            this.undeMajor = undeMajor;
            this.available = available;
            this.underSpecialization = underSpecialization;
        }
    }
}