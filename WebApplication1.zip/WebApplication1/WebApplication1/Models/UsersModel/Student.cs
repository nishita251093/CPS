﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class  Student : User
    {
        String admittedSemester;
        String admittedMajor;
        Boolean isFoundationAssigned;
        String assignedFaculty;
        String assignedAdvioser;
        

        public Student(string admittedSemester, string admittedMajor, bool isFoundationAssigned, string assignedFaculty, string assignedAdvioser)
        {
            this.admittedSemester = admittedSemester;
            this.admittedMajor = admittedMajor;
            this.isFoundationAssigned = isFoundationAssigned;
            this.assignedFaculty = assignedFaculty;
            this.assignedAdvioser = assignedAdvioser;
            
        }

        public Student()
        {
            this.admittedSemester = "";
            this.admittedMajor = "";
            this.isFoundationAssigned = false;
            this.assignedFaculty = "";
            this.assignedAdvioser = "";
            
        }
    }

}