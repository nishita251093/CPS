﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Faculty : User
    {
        List<Student> studentsUnderFaculty;

        public Faculty(List<Student> studentsUnderFaculty)
        {
            this.studentsUnderFaculty = studentsUnderFaculty;
        }
    }
}