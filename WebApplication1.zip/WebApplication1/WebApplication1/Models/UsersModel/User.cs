﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class User
    {
        public  int uhclID;
        public String uhclIDPassword;
        String firstName;
        String lastName;
        int primaryContactNumber;
        int secondaryContactNumber;
        String uhclEmailID;
        String uhclEmailPassword;
        String address;
        String identifier;

        public User(int uhclID, string uhclIDPassword, string firstName, string lastName, int primaryContactNumber, int secondaryContactNumber, string uhclEmailID, string uhclEmailPassword, string address)
        {
            this.uhclID = uhclID;
            this.uhclIDPassword = uhclIDPassword;
            this.firstName = firstName;
            this.lastName = lastName;
            this.primaryContactNumber = primaryContactNumber;
            this.secondaryContactNumber = secondaryContactNumber;
            this.uhclEmailID = uhclEmailID;
            this.uhclEmailPassword = uhclEmailPassword;
            this.address = address;
        }

        public User()
        {
            this.uhclID = 0;
            this.uhclIDPassword = "";
            this.firstName = "";
            this.lastName = "";
            this.primaryContactNumber = 0;
            this.secondaryContactNumber = 0;
            this.uhclEmailID = "";
            this.uhclEmailPassword = "";
            this.address = "";
        }


        public int UhclID { get; set; }

        [Required(ErrorMessage = "Required.")]
        public string UhclEmailID { get; set; }

        [Required(ErrorMessage ="Required")]
        public string UhclEmailPassword { get; set; }

        public string Identifier { get; set; }

        public bool RememberMe { get; set; }



    }

}